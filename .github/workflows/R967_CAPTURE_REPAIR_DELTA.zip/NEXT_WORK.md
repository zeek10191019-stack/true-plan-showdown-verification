# R967 実機試験修繕

iOS差分の基準は GitHub の R966 コミット a3f15f0a489a4d244e0b08a67a91b856d836d6e9 から復元した706ファイルです。検証用 r967.yml は別ファイルで提供しています。GitHubでブランチ r938-export-recovery の .github/workflows に配置すると標準の xcode-27 ジョブ2本が起動します。Swift・Python・ブラウザー回帰、Vision実画像、arm64 iPhoneOSビルドを実行します。公開やIPAの生成工程は含みません。

R967_CAPTURE_REPAIRS.patch は復元した iOS source ディレクトリに patch -p1 で適用できます。R967_T023_CAPTURE_COMPATIBILITY.patch は offline を含むPC側の作業ルートに patch -p1 で適用できます。T023の盤面・合法手の条件は維持しています。

R967_VALIDATION.json に実機R966とローカル回帰の結果を格納しました。フレーム3843の欠落は元ログの実測です。修正後の欠落ゼロは同フレームの遅延完了を模した再生結果です。PNG圧縮の容量差は実機画像からのローカル試算です。

再開点は GitHub の書き込み経路の復旧と r967.yml の起動です。Swift/Visionの全対象とiPhoneOSビルドを通し、アプリに依存するJPEG/PNG出力と録画停止・再共有の回帰を確認してください。自他・現在ターンの独立照合、5件の本処理タイムアウト、79項目の実画面精度、判断依頼と合法手を含む実機通し試験は残っています。今回使った実機ZIPは再送不要です。
