R27.394 iPhone向けYAML取得パック

このZIPをiPhoneの「ファイル」アプリで開き、タップして展開してください。
展開後の r27394-ios27-sdk-diagnostic.yml をGitHubにアップロードしてください。
アップロード先: https://github.com/zeek10191019-stack/true-plan-showdown-verification/upload/main/.github/workflows
起動先: https://github.com/zeek10191019-stack/true-plan-showdown-verification/actions/workflows/r27394-ios27-sdk-diagnostic.yml

注意: GitHubにアップロードするのは .yml だけです。
このファイルは署名なしビルド診断であり、iPhoneへ実行可能なアプリをインストールするものではありません。
